
def calculate(a):
    return a + 10

    
