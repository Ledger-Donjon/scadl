import tensorflow as tf
from keras import preprocessing
import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Dense, Flatten

class profileEngine(Model):
    def __init__(self, x):
        super().__init__()
        self.model = model

    def train(self, x_train, y_train, epochs=300, batch_size=100):
        self.model.fit(x_train, y_train, epochs, batch_size)

    def save_model(self, name):
        self.model.save(name)



        


    








